package ro.tuc.ds2020.entities;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.persistence.Entity;
import java.io.Serializable;
import java.util.UUID;

@Entity
public class Person  implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO) // This assumes the underlying database supports auto increment
    private Integer id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "address", nullable = false)
    private String address;

    @Column(name = "age", nullable = false)
    private int age;

    @Column(name = "rol",nullable = false)
    private String rol;


    public Person() {
    }

    public Person(String name, String address, int age,String role) {
        this.name = name;
        this.address = address;
        this.age = age;
        this.rol = role;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getRole(){return rol; }

    public void setRole(String role) {
        System.out.println("Role received: [" + role + "]"); // Add this line
        if (!"admin".equals(role) && !"client".equals(role)) {
            throw new IllegalArgumentException("Invalid role provided: " + role);
        }
        this.rol = role;
    }

}
