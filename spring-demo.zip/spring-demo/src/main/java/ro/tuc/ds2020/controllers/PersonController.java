package ro.tuc.ds2020.controllers;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ro.tuc.ds2020.dtos.IdDTO;
import ro.tuc.ds2020.dtos.PersonDTO;
import ro.tuc.ds2020.dtos.PersonDetailsDTO;
import ro.tuc.ds2020.entities.Person;
import ro.tuc.ds2020.services.PersonService;
import org.springframework.web.client.RestTemplate;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@CrossOrigin
@RequestMapping(value = "/person")
public class PersonController {

    private final PersonService personService;
    private final RestTemplate restTemplate;
    private static final Logger LOGGER = LoggerFactory.getLogger(PersonController.class);


    @Autowired
    public PersonController(PersonService personService, RestTemplate restTemplate) {
        this.personService = personService;
        this.restTemplate = restTemplate;
    }
    @GetMapping()
    public ResponseEntity<List<PersonDTO>> getPersons() {
        List<PersonDTO> dtos = personService.findPersons();
        for (PersonDTO dto : dtos) {
            Link personLink = linkTo(methodOn(PersonController.class)
                    .getPerson(dto.getId())).withRel("personDetails");
            dto.add(personLink);
        }
        return new ResponseEntity<>(dtos, HttpStatus.OK);
    }

    @PostMapping()
    public ResponseEntity<?> insertProsumer(@Valid @RequestBody PersonDetailsDTO personDTO) {
        Integer personID = null;
        try {
            // Perform the insert operation with personService and get the ID
            personID = personService.insert(personDTO);

            // Create an IdDTO object with only the ID
            IdDTO idDTO = new IdDTO(personID);

            // API call to the external service with just the ID
            String url = "http://device-demo-app-service-device-1:8081/person";
            ResponseEntity<Integer> response = restTemplate.postForEntity(url, idDTO, Integer.class);

            // Check the response status
            if (response.getStatusCode().is2xxSuccessful()) {
                // Success handling: return the response body
                return new ResponseEntity<>(response.getBody(), HttpStatus.CREATED);
            } else {
                // If the API call was not successful, roll back the insert operation by deleting the person
                personService.delete(personID);
                // Return or handle the error
                return new ResponseEntity<>("Person inserted but external API call failed, rollback initiated.", HttpStatus.BAD_GATEWAY);
            }
        } catch (Exception e) {
            // If there was an exception during the API call, attempt to roll back the insert operation
            if (personID != null) {
                personService.delete(personID);
            }
            // Log the exception and return an appropriate response
            LOGGER.error("Failed to insert person and notify external service. Error: {}", e.getMessage());
            return new ResponseEntity<>("Failed to insert person or notify external service.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/{id}")
    public ResponseEntity<PersonDetailsDTO> getPerson(@PathVariable("id") Integer personId) {
        PersonDetailsDTO dto = personService.findPersonById(personId);
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    @PutMapping(value = "/{id}")
    public ResponseEntity<Integer> updatePerson(@PathVariable("id") Integer personID, @Valid @RequestBody PersonDetailsDTO personDTO) {
        Integer persId = personService.update(personID, personDTO);
        return new ResponseEntity<>(personID, HttpStatus.OK);

    }

    @DeleteMapping(value = "/{id}")
    public ResponseEntity<?> deletePerson(@PathVariable("id") Integer personId) {
        // Păstrați o copie a obiectului înainte de a-l șterge
        Person userOptional = personService.findById(personId);
        if (userOptional == null) {
            return new ResponseEntity<>("User not found.", HttpStatus.NOT_FOUND);
        }


        try {
            // Încercați să ștergeți persoana folosind serviciul dvs.
            personService.delete(personId);

            // Dacă ștergerea a fost cu succes, faceți apelul API către serviciul extern
            String externalServiceUrl = "http://device-demo-app-service-device-1:8081/person/" + personId;
            restTemplate.delete(externalServiceUrl);

            // Presupunem că apelul API a fost cu succes dacă nu s-a aruncat o excepție
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            // Dacă există o excepție, înseamnă că apelul API a eșuat
            // Încercați să restaurați utilizatorul șters
            LOGGER.error("Failed to delete user or notify external service. Error: {}", e.getMessage());
            return new ResponseEntity<>("Failed to notify external service about user deletion.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}