package ro.tuc.ds2020.dtos;

public class IdDTO {
    private Integer id;

    public IdDTO() {
    }

    public IdDTO(Integer id) {
        this.id = id;
    }

    // Getter and Setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
