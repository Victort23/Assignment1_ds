package ro.tuc.ds2020.dtos;

import ro.tuc.ds2020.dtos.validators.annotation.AgeLimit;

import javax.validation.constraints.NotNull;
import java.util.Objects;
import java.util.UUID;

public class PersonDetailsDTO {

    private Integer id;
    @NotNull
    private String name;
    @NotNull
    private String address;
    @AgeLimit(limit = 18)
    private int age;
    @NotNull
    private String rol;


    public PersonDetailsDTO() {
    }

    public PersonDetailsDTO( String name, String address, int age,String role) {
        this.name = name;
        this.address = address;
        this.age = age;
        this.rol=role;
    }

    public PersonDetailsDTO(Integer id, String name, String address, int age,String role) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.age = age;
        this.rol=role;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public String getRole() {
        return rol;
    }

    public void setRole(String role) {
        System.out.println("Role received: [" + role + "]"); // Add this line
        if (!"admin".equals(role) && !"client".equals(role)) {
            throw new IllegalArgumentException("Invalid role provided: " + role);
        }
        this.rol = role;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PersonDetailsDTO that = (PersonDetailsDTO) o;
        return age == that.age &&
                Objects.equals(name, that.name) &&
                Objects.equals(address, that.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, address, age);
    }
}
