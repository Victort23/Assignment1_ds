import React from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import NavigationBar from './navigation-bar'
import Home from './home/home';
import PersonContainer from './person/person-container'
import DeviceContainer from './device/device-container';
import ErrorPage from './commons/errorhandling/error-page';
import styles from './commons/styles/project-style.css';

class App extends React.Component {
    render() {
        return (
            <div className={styles.back}>
                <Router>
                    <div>
                        <NavigationBar />
                        <Routes>
                            <Route path='/' element={<Home/>} />
                            <Route path='/person' element={<PersonContainer/>} />
                            <Route path='/device' element={<DeviceContainer/>} />
                            <Route path='*' element={<ErrorPage/>} />
                        </Routes>
                    </div>
                </Router>
            </div>
        )
    };
}

export default App;
