import React from 'react';
import {FormGroup, Label, Input, Row, Col, Button} from 'reactstrap';
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";

function DeviceFormComponent(props) {
    return (
        <div>
            <FormGroup id='description'>
                <Label for='descriptionField'> Description: </Label>
                <Input name='description' id='descriptionField' placeholder={props.formControls.description.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.description.value}
                       touched={props.formControls.description.touched ? 1 : 0}
                       valid={props.formControls.description.valid}
                       required
                />
                {props.formControls.description.touched && !props.formControls.description.valid &&
                <div className={"error-message row"}> * Description must have at least 3 characters </div>}
            </FormGroup>

            <FormGroup id='address'>
                <Label for='addressField'> Address: </Label>
                <Input name='address' id='addressField' placeholder={props.formControls.address.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.address.value}
                       touched={props.formControls.address.touched ? 1 : 0}
                       valid={props.formControls.address.valid}
                       required
                />
            </FormGroup>

            <FormGroup id='maximumHourlyEnergyConsumption'>
                <Label for='consumptionField'> Max Hourly Consumption: </Label>
                <Input name='maximumHourlyEnergyConsumption' id='consumptionField' placeholder={props.formControls.maximumHourlyEnergyConsumption.placeholder}
                       type="text"
                       onChange={props.handleChange}
                       defaultValue={props.formControls.maximumHourlyEnergyConsumption.value}
                       touched={props.formControls.maximumHourlyEnergyConsumption.touched ? 1 : 0}
                       valid={props.formControls.maximumHourlyEnergyConsumption.valid}
                       required
                />
            </FormGroup>
            <FormGroup id='user'>
                <Label for='userField'> User ID: </Label>
                <Input
                    name='user'
                    id='userField'
                    placeholder={props.formControls.user.placeholder}
                    onChange={props.handleChange}
                    defaultValue={props.formControls.user.value}
                    touched={props.formControls.user.touched ? 1 : 0}
                    valid={props.formControls.user.valid}
                    required
                />
                {props.formControls.user.touched && !props.formControls.user.valid &&
                <div className={"error-message"}> * User ID is required </div>}
            </FormGroup>

            <Row>
                <Col sm={{size: '4', offset: 8}}>
                    <Button type={"submit"} disabled={!props.formIsValid} onClick={props.handleSubmit}> Submit </Button>
                </Col>
            </Row>

            {
                props.errorStatus > 0 &&
                <APIResponseErrorMessage errorStatus={props.errorStatus} error={props.error}/>
            }
        </div>
    );
}

export default DeviceFormComponent;
