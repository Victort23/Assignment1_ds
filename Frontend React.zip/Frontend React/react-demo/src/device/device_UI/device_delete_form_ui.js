import React from 'react';
import { FormGroup, Label, Input, Row, Col, Button } from 'reactstrap';
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";

function DeviceDeleteFormComponent(props) {
    return (
        <div>
            <FormGroup id='id'>
                <Label for='idField'> Device ID to delete: </Label>
                <Input name='id' id='idField' placeholder={props.formControls.id.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.id.value}
                       required />
            </FormGroup>

            <Row>
                <Col sm={{ size: '4', offset: 8 }}>
                    <Button type={"submit"} onClick={props.handleDelete}> Delete Device </Button>
                </Col>
            </Row>

            {
                props.errorStatus > 0 &&
                <APIResponseErrorMessage errorStatus={props.errorStatus} error={props.error} />
            }
        </div>
    );
}

export default DeviceDeleteFormComponent;
