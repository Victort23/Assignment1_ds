import React from 'react';
import {FormGroup, Label, Input, Row, Col, Button} from 'reactstrap';
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";

function DeviceUpdateFormComponent(props) {
    return (
        <div>
            <FormGroup id='id'>
    <Label for='idField'> ID: </Label>
    <Input name='id' id='idField' placeholder={props.formControls.id.placeholder}
           onChange={props.handleChange}
           defaultValue={props.formControls.id.value}
           touched={props.formControls.id.touched ? 1 : 0}
           valid={props.formControls.id.valid}
           required
    />
    {props.formControls.id.touched && !props.formControls.id.valid &&
    <div className={"error-message row"}> * ID is required </div>}
</FormGroup>

            <FormGroup id='description'>
                <Label for='descriptionField'> Description: </Label>
                <Input name='description' id='descriptionField' placeholder={props.formControls.description.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.description.value}
                       touched={props.formControls.description.touched ? 1 : 0}
                       valid={props.formControls.description.valid}
                       required
                />
                {props.formControls.description.touched && !props.formControls.description.valid &&
                <div className={"error-message row"}> * Description must have at least 3 characters </div>}
            </FormGroup>

            <FormGroup id='address'>
                <Label for='addressField'> Address: </Label>
                <Input name='address' id='addressField' placeholder={props.formControls.address.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.address.value}
                       touched={props.formControls.address.touched ? 1 : 0}
                       valid={props.formControls.address.valid}
                       required
                />
            </FormGroup>

            <FormGroup id='maximumHourlyEnergyConsumption'>
                <Label for='consumptionField'> Max Hourly Consumption: </Label>
                <Input name='maximumHourlyEnergyConsumption' id='consumptionField' placeholder={props.formControls.maximumHourlyEnergyConsumption.placeholder}
                       type="text"
                       onChange={props.handleChange}
                       defaultValue={props.formControls.maximumHourlyEnergyConsumption.value}
                       touched={props.formControls.maximumHourlyEnergyConsumption.touched ? 1 : 0}
                       valid={props.formControls.maximumHourlyEnergyConsumption.valid}
                       required
                />
            </FormGroup>

            <Row>
                <Col sm={{size: '4', offset: 8}}>
                    <Button type={"submit"} disabled={!props.formIsValid} onClick={props.handleUpdate}> Submit </Button>
                </Col>
            </Row>

            {
                props.errorStatus > 0 &&
                <APIResponseErrorMessage errorStatus={props.errorStatus} error={props.error}/>
            }
        </div>
    );
}

export default DeviceUpdateFormComponent;
