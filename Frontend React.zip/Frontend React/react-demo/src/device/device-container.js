import React from 'react';
import APIResponseErrorMessage from "../commons/errorhandling/api-response-error-message";
import {
    Button,
    Card,
    CardHeader,
    Col,
    Modal,
    ModalBody,
    ModalHeader,
    Row
} from 'reactstrap';
import DeviceForm from "./components/device_form_add";

import * as API_DEVICES from "./api/device-api"
import DeviceTable from "./components/device-table";
import DeviceUpdateForm from "./components/device_form_update";
import DeviceDeleteForm from './components/device_form_delete';
//import DeleteDeviceForm from "./components/device_delete_form";

class DeviceContainer extends React.Component {

    constructor(props) {
        super(props);
        this.toggleForm = this.toggleForm.bind(this);
        this.reload = this.reload.bind(this);
        this.state = {
            selected: false,
            updateSelected: false,
            deleteSelected: false,
            collapseForm: false,
            tableData: [],
            isLoaded: false,
            errorStatus: 0,
            error: null
        };
        this.toggleUpdateForm = this.toggleUpdateForm.bind(this); 
        this.toggleDeleteForm = this.toggleDeleteForm.bind(this);
    }

    componentDidMount() {
        this.fetchDevices();
    }

    fetchDevices() {
        return API_DEVICES.getDevices((result, status, err) => {
            if (result !== null && status === 200) {
                this.setState({
                    tableData: result,
                    isLoaded: true
                });
            } else {
                this.setState(({
                    errorStatus: status,
                    error: err
                }));
            }
        });
    }

    toggleForm() {
        this.setState({ selected: !this.state.selected });
    }
    toggleUpdateForm() {
        this.setState({ updateSelected: !this.state.updateSelected });
    }
    toggleDeleteForm() {
        this.setState({ deleteSelected: !this.state.deleteSelected });
    }

    reload() {
        this.setState({
            isLoaded: false
        });
       
        this.fetchDevices();
    }

    render() {
        return (
            <div>
                <CardHeader>
                    <strong> Device Management </strong>
                </CardHeader>
                <Card>
                    <br/>
                    <Row>
                        <Col sm={{ size: '2', offset: 1 }}>
                            <Button color="primary" onClick={this.toggleForm}>Add Device</Button>
                        </Col>
                        <Col sm={{ size: '2' }}>
                            <Button color="warning" onClick={this.toggleUpdateForm}>Update Device</Button>
                        </Col>
                        <Col sm={{ size: '2' }}>
                            <Button color="danger" onClick={this.toggleDeleteForm}>Delete Device</Button>
                        </Col>
                    </Row>

                    <br/>
                    <Row>
                        <Col sm={{ size: '8', offset: 1 }}>
                            {this.state.isLoaded && <DeviceTable tableData={this.state.tableData} />}
                            {this.state.errorStatus > 0 && <APIResponseErrorMessage
                                                            errorStatus={this.state.errorStatus}
                                                            error={this.state.error}
                                                        />}
                        </Col>
                    </Row>
                </Card>

                <Modal isOpen={this.state.selected} toggle={this.toggleForm}
                       className={this.props.className} size="lg">
                    <ModalHeader toggle={this.toggleForm}> Add Device: </ModalHeader>
                    <ModalBody>
                        <DeviceForm reloadHandler={this.reload} />
                    </ModalBody>
                </Modal>

             

                <Modal isOpen={this.state.updateSelected} toggle={this.toggleUpdateForm} className={this.props.className} size="lg">
                    <ModalHeader toggle={this.toggleUpdateForm}> Update Device: </ModalHeader>
                <ModalBody>
                <DeviceUpdateForm reloadHandler={this.reload} toggleUpdateForm={this.toggleUpdateForm} />
                </ModalBody>
                </Modal>


                <Modal isOpen={this.state.deleteSelected} toggle={this.toggleDeleteForm}
                       className={this.props.className} size="lg">
                    <ModalHeader toggle={this.toggleDeleteForm}> Delete Device: </ModalHeader>
                    <ModalBody>
                        <DeviceDeleteForm reloadHandler={this.reload} />
                    </ModalBody>
                </Modal>

              
            </div> 
        )
    }
}

export default DeviceContainer;
