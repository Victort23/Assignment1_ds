import { HOST } from "../../commons/hosts";
import RestApiClient from "../../commons/api/rest-client";


const endpoint = {
    device: '/device'
};

function getDevices(callback) {
    let request = new Request(HOST.backend_api_device + endpoint.device, {
        method: 'GET',
    });
    console.log(request.url);
    RestApiClient.performRequest(request, callback);
}

function getDeviceId(params, callback){
    let request = new Request(HOST.backend_api_device + endpoint.device + params.id, {
       method: 'GET'
    });

    console.log(request.url);
    RestApiClient.performRequest(request, callback);
}

function postDevice(device, callback){
    let request = new Request(HOST.backend_api_device + endpoint.device , {
        method: 'POST',
        headers : {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(device)
    });

    console.log("URL: " + request.url);

    RestApiClient.performRequest(request, callback);
}
function putDevice(id,device,callback){
    let request = new Request(HOST.backend_api_device + endpoint.device + '/' + id ,{
            method: 'PUT',
            headers: {'Accept': 'application/json',
            'Content-Type': 'application/json',},
            body: JSON.stringify(device)
    })
    console.log("URL: " + request.url);
    RestApiClient.performRequest(request, callback);
}
function deleteDevice(id,callback){
    let request = new Request(HOST.backend_api_device + endpoint.device + '/' + id, {
        method: 'DELETE',
        headers: {'Accept': 'application/json',
            'Content-Type': 'application/json',}
    });
    console.log("URL: " + request.url);
    RestApiClient.performRequest(request,callback);
}

export {
    getDevices,
    getDeviceId,
    postDevice,
    putDevice,
    deleteDevice
};
