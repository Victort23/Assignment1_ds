import React from 'react';
import Button from "react-bootstrap/Button";
import * as API_DEVICES from "../api/device-api";
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";
import {Col, Row} from "reactstrap";
import { FormGroup, Input, Label} from 'reactstrap';
import DeviceFormComponent from '../device_UI/device_add_form_ui';
import validateDevice from '../validators/device-validators';

class DeviceForm extends React.Component {
    constructor(props) {
        super(props);
        this.reloadHandler = this.props.reloadHandler;

        this.state = {
            errorStatus: 0,
            error: null,
            formIsValid: false,
            formControls: {
                user: { 
                    value: '',
                    placeholder: 'User ID...',
                    valid: false,
                    touched: false,
                    validationRules: {
                        isRequired: true
                    }
                },
                description: {
                    value: '',
                    placeholder: 'Device description...',
                    valid: false,
                    touched: false,
                    validationRules: {
                        minLength: 3,
                        isRequired: true
                    }
                },
                address: {
                    value: '',
                    placeholder: 'Device address...',
                    valid: false,
                    touched: false,
                },
                maximumHourlyEnergyConsumption: {
                    value: '',
                    placeholder: 'Max hourly consumption...',
                    valid: false,
                    touched: false,
                }
            }
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange = event => {

        const name = event.target.name;
        const value = event.target.value;

        const updatedControls = this.state.formControls;

        const updatedFormElement = updatedControls[name];

        updatedFormElement.value = value;
        updatedFormElement.touched = true;
        updatedFormElement.valid = validateDevice(value, updatedFormElement.validationRules);
        updatedControls[name] = updatedFormElement;

        let formIsValid = true;
        for (let updatedFormElementName in updatedControls) {
            formIsValid = updatedControls[updatedFormElementName].valid && formIsValid;
        }

        this.setState({
            formControls: updatedControls,
            formIsValid: formIsValid
        });

    };

    registerDevice(device) {
        return API_DEVICES.postDevice(device, (result, status, error) => {
            if (result !== null && (status === 200 || status === 201)) {
                console.log("Successfully inserted person with id: " + result);
                this.reloadHandler();
            } else {
                this.setState(({
                    errorStatus: status,
                    error: error
                }));
            }
        });
    }

    handleSubmit = () => {
        let device = {
            description: this.state.formControls.description.value,
            address: this.state.formControls.address.value,
            maximumHourlyEnergyConsumption: this.state.formControls.maximumHourlyEnergyConsumption.value,
            user: { id: this.state.formControls.user.value } // This should be a valid ID from your backend
        };
    
        console.log(device);
        this.registerDevice(device);
    };
    

    render() {
        return <DeviceFormComponent 
            handleChange={this.handleChange}
            handleSubmit={this.handleSubmit}
            formControls={this.state.formControls}
            formIsValid={this.state.formIsValid}
            errorStatus={this.state.errorStatus}
            error={this.state.error}
        />;
    }
}

export default DeviceForm;
