import React from 'react';
import validateDevice from '../validators/device-validators';import DeviceDeleteFormComponent from '../device_UI/device_delete_form_ui';
import * as API_DEVICES from "../api/device-api";

class DeviceDeleteForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            errorStatus: 0,
            error: null,
            formIsValid: false,
            formControls: {
                id: {
                    value: '',
                    placeholder: 'Device ID to delete...',
                    valid: false,
                    touched: false,
                    validationRules: {
                        isRequired: true
                    }
                }
            }
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
    }

    handleChange(event) {
        const name = event.target.name;
        const value = event.target.value;

        const updatedControls = this.state.formControls;
        const updatedFormElement = updatedControls[name];

        updatedFormElement.value = value;
        updatedFormElement.touched = true;
        updatedFormElement.valid = validateDevice(value, updatedFormElement.validationRules);
        updatedControls[name] = updatedFormElement;

        let formIsValid = true;
        for (let updatedFormElementName in updatedControls) {
            formIsValid = updatedControls[updatedFormElementName].valid && formIsValid;
        }

        this.setState({
            formControls: updatedControls,
            formIsValid: formIsValid
        });
    }

    deleteDevice(deviceId) {
        return API_DEVICES.deleteDevice(deviceId, (result, status, error) => {
            if (result !== null && (status === 200 || status === 204)) {
                console.log("Successfully deleted device with id: " + deviceId);
                this.props.reloadHandler(); // Assuming you want to reload after a successful deletion
            } else {
                this.setState({
                    errorStatus: status,
                    error: error,
                },);
            }
            this.props.reloadHandler();
        });
    }

    handleDelete() {
        let deviceId = this.state.formControls.id.value;

        if (this.state.formIsValid) {
            try {
                this.deleteDevice(deviceId);
            } catch (error) {
                console.error('An error occurred:', error);
                this.setState({
                    errorStatus: 'Error',
                    error: error
                });
            }
        }
    }

    render() {
        return (
            <DeviceDeleteFormComponent
                formControls={this.state.formControls}
                handleChange={this.handleChange}
                handleDelete={this.handleDelete}
                formIsValid={this.state.formIsValid}
                errorStatus={this.state.errorStatus}
                error={this.state.error}
            />
        );
    }
}

export default DeviceDeleteForm;
