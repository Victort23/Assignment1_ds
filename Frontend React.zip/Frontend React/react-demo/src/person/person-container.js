import React from 'react';
import APIResponseErrorMessage from "../commons/errorhandling/api-response-error-message";
import {
    Button,
    Card,
    CardHeader,
    Col,
    Modal,
    ModalBody,
    ModalHeader,
    Row
} from 'reactstrap';
import PersonForm from "./components/person-form";

import * as API_USERS from "./api/person-api"
import PersonTable from "./components/person-table";
import UpdatePersonForm from "./components/person_update_form";
import DeletePersonForm from "./components/person_delete_form";



class PersonContainer extends React.Component {

    constructor(props) {
        super(props);
        this.toggleForm = this.toggleForm.bind(this);
        this.reload = this.reload.bind(this);
        this.state = {
            selected: false,
            updateSelected: false,
            deleteSelected:false,
            collapseForm: false,
            tableData: [],
            isLoaded: false,
            errorStatus: 0,
            error: null
        };
        this.toggleUpdateForm = this.toggleUpdateForm.bind(this); 
        this.toggleDeleteForm = this.toggleDeleteForm.bind(this);
    }

    componentDidMount() {
        this.fetchPersons();
    }

    fetchPersons() {
        return API_USERS.getPersons((result, status, err) => {

            if (result !== null && status === 200) {
                this.setState({
                    tableData: result,
                    isLoaded: true
                });
            } else {
                this.setState(({
                    errorStatus: status,
                    error: err
                }));
            }
        });
    }

    toggleForm() {
        this.setState({selected: !this.state.selected});
    }
    toggleUpdateForm() {
        this.setState({ updateSelected: !this.state.updateSelected });
    }
    toggleDeleteForm() {
        this.setState({ deleteSelected: !this.state.deleteSelected });
    }

    reload() {
        this.setState({
            isLoaded: false
        });
       
        this.fetchPersons();
    }

    render() {
        return (
            <div>
                <CardHeader>
                    <strong> Person Management </strong>
                </CardHeader>
                <Card>
                    <br/>
                    <Row>
                        <Col sm={{size: '2', offset: 1}}>
                            <Button color="primary" onClick={this.toggleForm}>Add Person</Button>
                        </Col>
                        <Col sm={{size: '2'}}>
                            <Button color="warning" onClick={this.toggleUpdateForm}>Update Person</Button>
                        </Col>
                        <Col sm={{size: '2'}}>
                            <Button color="danger" onClick={this.toggleDeleteForm}>Delete Person</Button>
                        </Col>
                    </Row>

                    <br/>
                    <Row>
                        <Col sm={{size: '8', offset: 1}}>
                            {this.state.isLoaded && <PersonTable tableData = {this.state.tableData}/>}
                            {this.state.errorStatus > 0 && <APIResponseErrorMessage
                                                            errorStatus={this.state.errorStatus}
                                                            error={this.state.error}
                                                        />   }
                        </Col>
                    </Row>
                </Card>

                <Modal isOpen={this.state.selected} toggle={this.toggleForm}
                       className={this.props.className} size="lg">
                    <ModalHeader toggle={this.toggleForm}> Add Person: </ModalHeader>
                    <ModalBody>
                        <PersonForm reloadHandler={this.reload}/>
                    </ModalBody>
                </Modal>

                <Modal isOpen={this.state.updateSelected} toggle={this.toggleUpdateForm} //La update la buton 
                        className={this.props.className} size="lg">
                    <ModalHeader toggle={this.toggleUpdateForm}> Update Person: </ModalHeader>
                    <ModalBody>
                     <UpdatePersonForm reloadHandler={this.reload} />
                    </ModalBody>
                </Modal>
            <Modal isOpen={this.state.deleteSelected} toggle={this.toggleDeleteForm}
                    className={this.props.className} size="lg">
                <ModalHeader toggle={this.toggleDeleteForm}> Delete Person: </ModalHeader>
                <ModalBody>
                    <DeletePersonForm reloadHandler={this.reload} />
                </ModalBody>
            </Modal>
            </div>
        )

    }
}


export default PersonContainer;
