import React from 'react';
import validate from "./validators/person-validators";
import DeletePersonFormComponent from '../person_ui/person_form_delete';
import * as API_USERS from "../api/person-api";

class DeletePersonForm extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            errorStatus: 0,
            error: null,
            formIsValid: false,

            formControls: {
                id: {
                    value: '',
                    placeholder: 'ID of the person to delete...',
                    valid: false,
                    touched: false,
                    validationRules: {
                        isRequired: true
                    }
                }
            }
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
    }

    handleChange(event) {
        const name = event.target.name;
        const value = event.target.value;

        const updatedControls = this.state.formControls;
        const updatedFormElement = updatedControls[name];

        updatedFormElement.value = value;
        updatedFormElement.touched = true;
        updatedFormElement.valid = validate(value, updatedFormElement.validationRules);
        updatedControls[name] = updatedFormElement;

        let formIsValid = true;
        for (let updatedFormElementName in updatedControls) {
            formIsValid = updatedControls[updatedFormElementName].valid && formIsValid;
        }

        this.setState({
            formControls: updatedControls,
            formIsValid: formIsValid
        });
    }

    deletePerson(personId) {
        return API_USERS.deletePerson(personId, (result, status, error) => {
            if (result !== null && (status === 200 || status === 201)) {
                console.log("Successfully deleted person with id: " + result);
                this.props.reloadHandler(); // Assuming you want to reload after a successful deletion
            } else {
                this.props.reloadHandler();
                this.setState(({
                    errorStatus: status,
                    error: error
                }));
            }
        });
        
    }

    handleDelete() {
        let personId = this.state.formControls.id.value;
        
        try {
            this.deletePerson(personId);
        } catch (error) {
            console.error('An error occurred:', error);
            this.setState({
                errorStatus: 'Error',
                error: error
            });
        }
    }
    

    render() {
        return (
            <DeletePersonFormComponent 
                formControls={this.state.formControls}
                handleChange={this.handleChange}
                handleDelete={this.handleDelete}
                formIsValid={this.state.formIsValid}
                errorStatus={this.state.errorStatus}
                error={this.state.error}
                //toggleDeleteForm={this.toggleDeleteForm}
            />
        );
    }
}

export default DeletePersonForm;
