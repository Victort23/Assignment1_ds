import React from 'react';
import validate from "./validators/person-validators";
import Button from "react-bootstrap/Button";
import * as API_USERS from "../api/person-api";
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";
import {Col, Row} from "reactstrap";
import { FormGroup, Input, Label} from 'reactstrap';
import PersonFormComponent from '../person_ui/person_form_content';



class PersonForm extends React.Component {

    constructor(props) {
        super(props); //props , like context in Flutter ,pass data from parent to child
        this.toggleForm = this.toggleForm.bind(this);
        this.reloadHandler = this.props.reloadHandler;

        this.state = { //initializeaza state-ul componentului

            errorStatus: 0,
            error: null,

            formIsValid: false,
            isUpdateMode: false,

            formControls: {
                name: {
                    value: '',
                    placeholder: 'What is your name?...',
                    valid: false,
                    touched: false,
                    validationRules: {
                        minLength: 3,
                        isRequired: true
                    }
                },
                email: {
                    value: '',
                    placeholder: 'Email...',
                    valid: false,
                    touched: false,
                    validationRules: {
                        emailValidator: true
                    }
                },
                age: {
                    value: '',
                    placeholder: 'Age...',
                    valid: false,
                    touched: false,
                },
                address: {
                    value: '',
                    placeholder: 'Cluj, Zorilor, Str. Lalelelor 21...',
                    valid: false,
                    touched: false,
                },
                role: {
                    value: 'client',
                    placeholder: 'client/admin',
                    valid: false,
                    touched: false,
                }
            }
        };

        this.handleChange = this.handleChange.bind(this); //fac bind metodelor la instanta clasei actuale (this) in acest caz
        this.handleSubmit = this.handleSubmit.bind(this);
        
      
        /*By binding the method to the current instance of the class, you're ensuring that this inside the method
         always refers to the component instance, allowing you to interact with component properties, state, and other methods.*/ 
    }
    //You can attach event handlers to elements and manage user interactions.

    toggleForm() {
        this.setState({collapseForm: !this.state.collapseForm});
    } /*The purpose of the method, as suggested by its name and behavior, is to toggle the visibility (or some behavior) of a form.
     If collapseForm is true, invoking toggleForm will set it to false, and vice versa.*/


    handleChange = event => {

        const name = event.target.name;
        const value = event.target.value;

        const updatedControls = this.state.formControls;

        const updatedFormElement = updatedControls[name];

        updatedFormElement.value = value;
        updatedFormElement.touched = true;
        updatedFormElement.valid = validate(value, updatedFormElement.validationRules);
        updatedControls[name] = updatedFormElement;

        let formIsValid = true;
        for (let updatedFormElementName in updatedControls) {
            formIsValid = updatedControls[updatedFormElementName].valid && formIsValid;
        }

        this.setState({
            formControls: updatedControls,
            formIsValid: formIsValid
        });

    };

    registerPerson(person) {
        return API_USERS.postPerson(person, (result, status, error) => {
            if (result !== null && (status === 200 || status === 201)) {
                console.log("Successfully inserted person with id: " + result);
                this.reloadHandler();
            } else {
                this.setState(({
                    errorStatus: status,
                    error: error
                }));
            }
        });
    }

    handleSubmit() {
        let person = {
            name: this.state.formControls.name.value,
            email: this.state.formControls.email.value,
            age: this.state.formControls.age.value,
            address: this.state.formControls.address.value,
            role: this.state.formControls.role.value
        };

        console.log(person);
        this.registerPerson(person);
    }
    
    

    render() {
        return <PersonFormComponent 
        handleChange={this.handleChange}
        handleSubmit={this.handleSubmit}
        formControls={this.state.formControls}
        formIsValid={this.state.formIsValid}
        errorStatus={this.state.errorStatus}
        error={this.state.error}
       
    />;
            
    }
}

export default PersonForm;
