import React from 'react';
import {FormGroup, Label, Input, Row, Col, Button} from 'reactstrap';
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";

function UpdatePersonFormComponent(props) {
    return (
        <div>
            <FormGroup id='id'>
    <Label for='idField'> ID: </Label>
    <Input name='id' id='idField' placeholder={props.formControls.id.placeholder}
           onChange={props.handleChange}
           defaultValue={props.formControls.id.value}
           touched={props.formControls.id.touched ? 1 : 0}
           valid={props.formControls.id.valid}
           required
    />
    {props.formControls.id.touched && !props.formControls.id.valid &&
    <div className={"error-message row"}> * ID is required </div>}
</FormGroup>

            <FormGroup id='name'>
                <Label for='nameField'> Name: </Label>
                <Input name='name' id='nameField' placeholder={props.formControls.name.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.name.value}
                       touched={props.formControls.name.touched ? 1 : 0}
                       valid={props.formControls.name.valid}
                       required
                />
                {props.formControls.name.touched && !props.formControls.name.valid &&
                <div className={"error-message row"}> * Name must have at least 3 characters </div>}
            </FormGroup>

            <FormGroup id='email'>
                <Label for='emailField'> Email: </Label>
                <Input name='email' id='emailField' placeholder={props.formControls.email.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.email.value}
                       touched={props.formControls.email.touched ? 1 : 0}
                       valid={props.formControls.email.valid}
                       required
                />
                {props.formControls.email.touched && !props.formControls.email.valid &&
                <div className={"error-message"}> * Email must have a valid format</div>}
            </FormGroup>

            <FormGroup id='address'>
                <Label for='addressField'> Address: </Label>
                <Input name='address' id='addressField' placeholder={props.formControls.address.placeholder}
                       onChange={props.handleChange}
                       defaultValue={props.formControls.address.value}
                       touched={props.formControls.address.touched ? 1 : 0}
                       valid={props.formControls.address.valid}
                       required
                />
            </FormGroup>

            <FormGroup id='age'>
                <Label for='ageField'> Age: </Label>
                <Input name='age' id='ageField' placeholder={props.formControls.age.placeholder}
                       min={0} max={100} type="number"
                       onChange={props.handleChange}
                       defaultValue={props.formControls.age.value}
                       touched={props.formControls.age.touched ? 1 : 0}
                       valid={props.formControls.age.valid}
                       required
                />
            </FormGroup>

            <FormGroup id='role'>
                <Label for='roleField'> Role: </Label>
                <Input type="select" name="role" id="roleField" 
                       value={props.formControls.role.value}
                       onChange={props.handleChange} 
                       required>
                    <option value="client">Client</option>
                    <option value="admin">Admin</option>
                </Input>
            </FormGroup>        

            <Row>
                <Col sm={{size: '4', offset: 8}}>
                    <Button type={"submit"} disabled={!props.formIsValid} onClick={props.handleUpdate}>Update</Button>
                </Col>
            </Row>

            {
                props.errorStatus > 0 &&
                <APIResponseErrorMessage errorStatus={props.errorStatus} error={props.error}/>
            }
        </div>
    );
}
        
export default UpdatePersonFormComponent;
