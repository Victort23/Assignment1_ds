import React from 'react';
import {FormGroup, Label, Input, Row, Col, Button} from 'reactstrap';
import APIResponseErrorMessage from "../../commons/errorhandling/api-response-error-message";


function DeletePersonFormComponent(props) {
    return (
        <div>
            <FormGroup id='id'>
                <Label for='idField'> ID: </Label>
                <Input name='id' id='idField' placeholder='Person ID to delete...'
                       onChange={props.handleChange}
                       value={props.formControls.id.value}       
                       required />
                {props.formControls.id.touched && !props.formControls.id.valid &&
                <div className={"error-message"}> * ID is required </div>}
            </FormGroup>
            <Button type="submit" disabled={!props.formIsValid} onClick={props.handleDelete}>Delete</Button>
        </div>
    );
}

export default DeletePersonFormComponent;

