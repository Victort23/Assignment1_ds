// src/commons/login/LoginComponent.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const LoginComponent = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLogin = async (event) => {
        event.preventDefault();
        try {
            const response = await fetch('/api/authenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });
    
            const data = await response.json();
    
            if (response.ok) {
                // Assuming your backend sends back a user object with a role
                localStorage.setItem('token', data.token); // Save the token
                localStorage.setItem('role', data.user.role); // Save the user role
    
                if (data.user.role === 'admin') {
                    navigate('/person'); // Redirect to admin page
                } else {
                    navigate('/'); // Redirect to client page or home page
                }
            } else {
                throw new Error(data.message || 'Login failed');
            }
        } catch (error) {
            console.error('Login Error:', error);
            // Here, you should handle the login error,
            // maybe set an error message in your state and display it to the user
        }
    };
    

    return (
        <form onSubmit={handleLogin}>
            <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
            />
            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <button type="submit">Login</button>
        </form>
    );
};

export default LoginComponent;
