export const HOST = {
    backend_api: 'http://localhost:8085',
    backend_api_device:'http://localhost:8086'
};
