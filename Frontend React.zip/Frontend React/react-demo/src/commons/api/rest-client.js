function performRequest(request, callback) {
    fetch(request)
        .then(function (response) {
            if (response.ok) {
                return response.json().then(json => callback(json, response.status, null));
            } else {
                return response.json().then(err => callback(null, response.status, err));
            }
        })
        .catch(function (err) {
            console.error('Fetch error:', err);
            console.error('Error details:', err.message);
            // You might want to log the entire error object if you're unsure what's inside it
            console.error('Error object:', err);
            callback(null, 1, err);
        });
        
}

module.exports = {
    performRequest
};
