package ro.tuc.ds2020.dtos;


import ro.tuc.ds2020.entities.User;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.PrintStream;
import java.util.Objects;


public class DeviceDetailsDTO {

    private Integer id;
    private User user;
    @NotNull
    private String description;
    @NotNull
    private String address;
    @NotNull
    private String maximumHourlyEnergyConsumption;

    public DeviceDetailsDTO() {
    }

    public DeviceDetailsDTO(String description, String address, String maximum_hourly_energy_consumption) {
        this.description = description;
        this.address = address;
        this.maximumHourlyEnergyConsumption = maximum_hourly_energy_consumption;
    }

    public DeviceDetailsDTO(Integer id, String description, String address, String maximum_hourly_energy_consumption) {
        this.id = id;
        this.description = description;
        this.address = address;
        this.maximumHourlyEnergyConsumption = maximum_hourly_energy_consumption;
    }
    public DeviceDetailsDTO(Integer id, String description, String address, String maximum_hourly_energy_consumption,User user) {
        this.id = id;
        this.description = description;
        this.address = address;
        this.maximumHourlyEnergyConsumption = maximum_hourly_energy_consumption;
        this.user=user;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMaximumHourlyEnergyConsumption() {
        return maximumHourlyEnergyConsumption;
    }

    public void setMaximumHourlyEnergyConsumption(String maximum_hourly_energy_consumption) {
        this.maximumHourlyEnergyConsumption = maximum_hourly_energy_consumption;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DeviceDetailsDTO that = (DeviceDetailsDTO) o;
        return maximumHourlyEnergyConsumption == that.maximumHourlyEnergyConsumption &&
                Objects.equals(description, that.description) &&
                Objects.equals(address, that.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(description, address, maximumHourlyEnergyConsumption);
    }
}
