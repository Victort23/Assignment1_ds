package ro.tuc.ds2020.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ro.tuc.ds2020.controllers.handlers.exceptions.model.ResourceNotFoundException;
import ro.tuc.ds2020.entities.User;
import ro.tuc.ds2020.repositories.UserRespository;

import java.util.List;
import java.util.Optional;
@Service
public class UserService {
    private final UserRespository userRespository;
    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
    @Autowired
    public UserService(UserRespository userRespository) {
        this.userRespository = userRespository;
    }

    public Integer insert(User user) {
        user = userRespository.save(user);
        LOGGER.debug("Person with id {} was inserted in db", user.getId());
        return user.getId();
    }
    public List<User> getAllUsers() {
        return userRespository.findAll();
    }
    public void delete(Integer id) {
        Optional<User> personOptional = userRespository.findById(id);
        if (!personOptional.isPresent()) {
            LOGGER.error("Person with id {} was not found in db", id);
            throw new ResourceNotFoundException(User.class.getSimpleName() + " with id: " + id);
        }
        userRespository.delete(personOptional.get());
    }
}
