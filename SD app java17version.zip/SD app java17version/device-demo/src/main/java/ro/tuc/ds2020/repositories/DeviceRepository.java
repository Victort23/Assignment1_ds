package ro.tuc.ds2020.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ro.tuc.ds2020.entities.Device;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface DeviceRepository extends JpaRepository<Device, Integer> {

    /**
     * Example: JPA generate Query by Field
     */
    List<Device> findByDescription(String description);

    /**
     * Example: Write Custom Query
     * Note: This is just a sample query; you'll need to adjust it based on the actual requirements for the Device entity.
     */
    @Query(value = "SELECT d " +
            "FROM Device d " +
            "WHERE d.description = :description " +
            "AND d.maximumHourlyEnergyConsumption >= 60  ") // Adjusted condition for demonstration purposes
    Optional<Device> findHighConsumptionDevicesByDescription(@Param("description") String description);

}
