package ro.tuc.ds2020.entities;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users") // 'user' is often a reserved keyword in SQL, so it's renamed to 'users'
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Transactional
public class User implements Serializable {

    @Id
    private Integer id;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private Set<Device> devices = new HashSet<>();

    // Other fields and methods can be added here as needed

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                '}';
    }


    // Other fields and methods can be added here as needed
}
